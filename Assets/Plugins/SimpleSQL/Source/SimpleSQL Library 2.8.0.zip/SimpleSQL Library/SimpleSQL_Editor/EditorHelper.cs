using UnityEngine;
using UnityEditor;
using System;
using System.IO;
using System.Collections.Generic;
using System.Reflection;

namespace SimpleSQL
{
    static public class EditorHelper
    {
        static public void CreateAsset<T>(string assetName) where T : ScriptableObject
        {
            T asset = ScriptableObject.CreateInstance<T>();

            string path = AssetDatabase.GetAssetPath(Selection.activeObject);
            if (path == "")
            {
                path = "Assets";
            }
            else if (Path.GetExtension(path) != "")
            {
                path = path.Replace(Path.GetFileName(AssetDatabase.GetAssetPath(Selection.activeObject)), "");
            }

            string assetPathAndName = AssetDatabase.GenerateUniqueAssetPath(path + "/" + assetName + ".asset");

            AssetDatabase.CreateAsset(asset, assetPathAndName);

            AssetDatabase.SaveAssets();
            EditorUtility.FocusProjectWindow();
            Selection.activeObject = asset;
        }

        static public void CreateAssetFromEmbeddedResource(string resourcePath, string assetName)
        {
            string path = AssetDatabase.GetAssetPath(Selection.activeObject);
            if (path == "")
            {
                path = "Assets";
            }
            else if (Path.GetExtension(path) != "")
            {
                path = path.Replace(Path.GetFileName(AssetDatabase.GetAssetPath(Selection.activeObject)), "");
            }
            string assetPathAndName = AssetDatabase.GenerateUniqueAssetPath(path + "/" + assetName);

            if (EditorHelper.CreateFileFromEmbeddedResource(resourcePath, assetPathAndName))
            {
                AssetDatabase.ImportAsset(assetPathAndName);
                AssetDatabase.Refresh();
            }
        }


        static public bool CreateFileFromEmbeddedResource(string resourcePath, string filePath)
        {
            //Debug.Log(resourcePath);

            FileInfo fi = new FileInfo(filePath);
            fi.Directory.Create();

            Stream myStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourcePath);
            if (myStream != null)
            {
                try
                {
                    File.WriteAllBytes(filePath, ReadToEnd(myStream));
                    myStream.Close();
                }
                catch (Exception ex)
                {
                    if (myStream != null)
                    {
                        myStream.Close();
                    }

                    Debug.LogError("Could not write resource to path: " + filePath + " " + ex.Message);
                }
            }
            else
            {
                Debug.LogError("Missing Dll resource: " + resourcePath);
                return false;
            }

            return true;
        }

        static public void DeleteFile(string filePath, bool clearEmptyDirectory, bool clearEmptyParentDirectory)
        {
            FileInfo fi = new FileInfo(filePath);
            if (fi.Exists)
            {
                fi.Delete();
                if (fi.Directory.Exists && clearEmptyDirectory)
                {
                    if (fi.Directory.GetFiles().Length == 0)
                    {
                        if (fi.Directory.GetDirectories().Length == 0)
                        {
                            fi.Directory.Delete();

                            if (clearEmptyParentDirectory)
                            {
                                if (fi.Directory.Parent.GetFiles().Length == 0)
                                {
                                    if (fi.Directory.Parent.GetDirectories().Length == 0)
                                    {
                                        fi.Directory.Parent.Delete();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        static private byte[] ReadToEnd(System.IO.Stream stream)
        {
            long originalPosition = 0;

            if (stream.CanSeek)
            {
                originalPosition = stream.Position;
                stream.Position = 0;
            }

            try
            {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                if (stream.CanSeek)
                {
                    stream.Position = originalPosition;
                }
            }
        }

        static public float KeepAngleInBounds(float angle)
        {
            float percent360F = (angle / 360.0f);
            int percent360I = Mathf.FloorToInt(angle / 360.0f);
            return ((percent360F - (float)percent360I) * 360.0f);
        }

        static public bool LeftMouseButton(Event evt)
        {
            return (evt.button == 0 && (!evt.alt) && (!evt.command));
        }

        static public bool RightMouseButton(Event evt)
        {
            return (evt.button == 1 || (evt.button == 0 && evt.alt));
        }

        static public bool MiddleMouseButton(Event evt)
        {
            return (evt.button == 2 || (evt.button == 0 && evt.command));
        }

        static public string GenerateIncrementedIndexedName(string name)
        {
            string[] s = name.Split(" "[0]);
            string firstPartOfName = "";
            if (s.Length > 1)
            {
                for (int i = 0; i < s.Length - 1; i++)
                {
                    firstPartOfName += s[i] + " ";
                }

                try
                {
                    name = firstPartOfName + (Convert.ToInt16(s[s.Length - 1]) + 1).ToString();
                }
                catch
                {
                    name = name + " 2";
                }
            }
            else
            {
                name = name + " 2";
            }

            return name;
        }

        static public float RoundFloat(float f, int decimalPlaces)
        {
            float mult = Mathf.Pow(10, decimalPlaces);
            return (Mathf.Round(f * mult) / mult);
        }

        static public Vector2 Vector3ToVector2(Vector3 v)
        {
            return new Vector2(v.x, v.y);
        }

        static public bool TransformedRectContains(Rect r, Matrix4x4 mat, Vector2 pos)
        {
            return (r.Contains(mat.inverse.MultiplyPoint3x4(new Vector3(pos.x, pos.y, 0))));
        }

        static public void SplitAssetPath(string path, bool showExtension, out string outPath, out string assetName)
        {
            outPath = "";
            assetName = "";

            string[] s = path.Split(@"/"[0]);
            if (s.Length > 0)
            {
                for (int i = 0; i < (s.Length - 1); i++)
                {
                    outPath += s[i] + @"/";
                }

                assetName = s[s.Length - 1];

                if (!showExtension)
                {
                    assetName = Path.GetFileNameWithoutExtension(assetName);
                }
            }
        }
    }
}